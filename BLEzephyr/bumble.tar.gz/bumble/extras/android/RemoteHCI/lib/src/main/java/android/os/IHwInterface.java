package android.os;

public interface IHwInterface {
    public IHwBinder asBinder();
}
