WEBSOCKET CLIENT TRANSPORT
==========================

The WebSocket Client transport is WebSocket connection to a WebSocket server over which HCI packets
are sent and received.

## Moniker
The moniker syntax for a WebSocket Client transport is: `ws-client:<ws-url>`

!!! example
    `ws-client:ws://localhost:1234/some/path`
